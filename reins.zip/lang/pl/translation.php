<?php

return[
'attributes'=>[
    'created_at'=>'Utworzono',
    'updated_at'=>'Zmodyfikowano',
    'deleted_at'=>'Usunięto',
    'name'=>'Nazwa',
    'surname'=>'Nazwisko',
    'thickness'=>'Grubość',
    'project'=>'Projekt',
    'worker'=>'Pracownik',
    'date'=>'Data',
    'quantityHours'=>'ilość godzin',

],
];
