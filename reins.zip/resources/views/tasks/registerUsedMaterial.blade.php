<x-app-layout>
<livewire:tasks.task-register-used-material/>
</x-app-layout>
