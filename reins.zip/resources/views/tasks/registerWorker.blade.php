<x-app-layout>
<livewire:tasks.task-register-worker/>
</x-app-layout>
