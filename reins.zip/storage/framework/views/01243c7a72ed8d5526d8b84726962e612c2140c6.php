<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8">
        <?php if(isset($material)): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('materials.material-form', ['material' => $material,'editMode' => true])->html();
} elseif ($_instance->childHasBeenRendered('HFAfcXk')) {
    $componentId = $_instance->getRenderedChildComponentId('HFAfcXk');
    $componentTag = $_instance->getRenderedChildComponentTagName('HFAfcXk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HFAfcXk');
} else {
    $response = \Livewire\Livewire::mount('materials.material-form', ['material' => $material,'editMode' => true]);
    $html = $response->html();
    $_instance->logRenderedChild('HFAfcXk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('materials.material-form', ['editMode' => false])->html();
} elseif ($_instance->childHasBeenRendered('hLrfKzw')) {
    $componentId = $_instance->getRenderedChildComponentId('hLrfKzw');
    $componentTag = $_instance->getRenderedChildComponentTagName('hLrfKzw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hLrfKzw');
} else {
    $response = \Livewire\Livewire::mount('materials.material-form', ['editMode' => false]);
    $html = $response->html();
    $_instance->logRenderedChild('hLrfKzw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Xampp\htdocs\AplikacjaInzynierska\resources\views/materials/materialtaskForm.blade.php ENDPATH**/ ?>
