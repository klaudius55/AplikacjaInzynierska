<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8">
        <?php if(isset($project)): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('projects.project-form', ['project' => $project,'editMode' => true])->html();
} elseif ($_instance->childHasBeenRendered('kyu0GhS')) {
    $componentId = $_instance->getRenderedChildComponentId('kyu0GhS');
    $componentTag = $_instance->getRenderedChildComponentTagName('kyu0GhS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kyu0GhS');
} else {
    $response = \Livewire\Livewire::mount('projects.project-form', ['project' => $project,'editMode' => true]);
    $html = $response->html();
    $_instance->logRenderedChild('kyu0GhS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('projects.project-form', ['editMode' => false])->html();
} elseif ($_instance->childHasBeenRendered('qOg0MNg')) {
    $componentId = $_instance->getRenderedChildComponentId('qOg0MNg');
    $componentTag = $_instance->getRenderedChildComponentTagName('qOg0MNg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qOg0MNg');
} else {
    $response = \Livewire\Livewire::mount('projects.project-form', ['editMode' => false]);
    $html = $response->html();
    $_instance->logRenderedChild('qOg0MNg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Xampp\htdocs\AplikacjaInzynierska\resources\views/projects/materialtaskForm.blade.php ENDPATH**/ ?>
