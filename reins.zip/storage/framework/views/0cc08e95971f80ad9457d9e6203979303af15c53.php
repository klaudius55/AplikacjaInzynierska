<div class="">
            <div class="flex justify-between mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="15fc792ab0cc9bea02d3166878873363">
    Wprowadź nazwę
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
                    <div class="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none
                text-secondary-400">
                                    <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
</svg>
                            </div>
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm pl-8" placeholder="Zadanie" wire:model="task.name" name="task.name" id="15fc792ab0cc9bea02d3166878873363" />

            </div>

    
                </div>
<?php /**PATH C:\Xampp\htdocs\AplikacjaInzynierska\storage\framework\views/fb376eb8e491d8e33eeba2d59d1412b72768cc65.blade.php ENDPATH**/ ?>