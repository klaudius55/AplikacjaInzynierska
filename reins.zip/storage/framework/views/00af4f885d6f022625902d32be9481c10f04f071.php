<div class="">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="fd30dd9113d47fc6fa8e5e42dbe6fc13">
    Wybierz
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500" wire:model="material.type_id" name="material.type_id" id="fd30dd9113d47fc6fa8e5e42dbe6fc13">
         <option>blacha</option>
                                <option>Profil 40x40</option>     </select>

    
                </div>
<?php /**PATH C:\Xampp\htdocs\AplikacjaInzynierska\storage\framework\views/c5010209af8d9cc4e2a0364342792038f2706795.blade.php ENDPATH**/ ?>